package com.test.aop2;

public interface Service {
	void getBoard();
	void addBoard();
	void delBoard();
}
