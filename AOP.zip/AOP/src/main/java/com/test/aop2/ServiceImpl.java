package com.test.aop2;

public class ServiceImpl implements Service{

	@Override
	public void getBoard() {
		System.out.println("ServiceImpl.getBoard() called");
	}

	@Override
	public void addBoard() {
		System.out.println("ServiceImpl.addBoard() called");
	}

	@Override
	public void delBoard() {
		System.out.println("ServiceImpl.delBoard() called");
	}

}
